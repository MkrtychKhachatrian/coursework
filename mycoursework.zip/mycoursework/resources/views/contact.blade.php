@extends('layouts.app')

@section('title')Заявка@endsection

@section('content')

    <div class="contact_block">
        <div class="form_content">
            <form action="{{ route('contact-form') }}" method="post">
                @csrf
                <h1 class="h_c">Запис до лікаря</h1>
                <div class="form_style">
                    <input type="text" name="name" placeholder="Ім’я*" id="name" class="input_style">
                </div>
                <div class="form_style">
                    <input type="text" name="email" placeholder="Email*" id="email" class="input_style">
                </div>
                <div class="form_style">
                    <textarea name="message" placeholder="Коментарі" id="message" class="textarea_style"></textarea>
                </div>
                <button type="submit" class="but_style">Відправити</button>
            </form>
        </div>
    </div>
@endsection
