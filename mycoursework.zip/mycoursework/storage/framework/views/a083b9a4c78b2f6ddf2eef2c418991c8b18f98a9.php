<?php $__env->startSection('title'); ?>Заявка<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="contact_block">
        <div class="form_content">
            <form action="<?php echo e(route('contact-form')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <h1 class="h_c">Запис до лікаря</h1>
                <div class="form_style">
                    <input type="text" name="name" placeholder="Ім’я*" id="name" class="input_style">
                </div>
                <div class="form_style">
                    <input type="text" name="email" placeholder="Email*" id="email" class="input_style">
                </div>
                <div class="form_style">
                    <textarea name="message" placeholder="Коментарі" id="message" class="textarea_style"></textarea>
                </div>
                <button type="submit" class="but_style">Відправити</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/mampstack-7.4.7-0/apache2/htdocs/mycoursework/resources/views/contact.blade.php ENDPATH**/ ?>