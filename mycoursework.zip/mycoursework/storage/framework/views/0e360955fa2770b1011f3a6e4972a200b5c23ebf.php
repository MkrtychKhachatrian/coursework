<?php $__env->startSection('title'); ?>Реєстрація<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="contact_block">
        <div class="form_content">
            <form action="<?php echo e(route('register')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <h1 class="h_c">Реєстрація</h1>
                <div class="form_style">
                    <input type="text" name="name" placeholder="Ім’я*" id="email" class="input_style">
                </div>
                <div class="form_style">
                    <input type="email" name="email" placeholder="Email*" id="email" class="input_style">
                </div>
                <div class="form_style">
                    <input type="password" name="password" placeholder="Пароль*" id="password" class="input_style">
                </div>
                <div class="form_style">
                    <input type="password" name="password" placeholder="Підтвердіть пароль*" id="password-confirm" class="input_style">
                </div>
                <button type="submit" class="but_style">Увійти</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/mampstack-7.4.7-0/apache2/htdocs/mycoursework/resources/views/auth/register.blade.php ENDPATH**/ ?>