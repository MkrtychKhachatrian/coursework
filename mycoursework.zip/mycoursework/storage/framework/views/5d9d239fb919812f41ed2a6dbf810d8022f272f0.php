<footer>
    <div class="footer1">
        <div class="footer1_content">
            <div class="footer1_1">
                <div class="logo_f" ><a href="<?php echo e(route('landing')); ?>"><img class="logo_pic_f" src="<?php echo e(asset('img/logo.png')); ?>"></a></div>
            </div>
            <div class="footer1_2">
                <div class="footer1_2_h">Контакти</div>
                <div class="footer1_2_text">healthyteeth@gmail.com</div>
                <div class="footer1_2_text">380973063626</div>
            </div>
            <div class="footer1_3">
                <div class="footer1_3_h">Адреса</div>
                <div class="footer1_3_text">Вул. Прилужна 8</div>
            </div>
        </div>
    </div>
    <div class="footer2">
        <div class="footer2_text">Healthyteeth © 2020</div>
    </div>
</footer>
<?php /**PATH /Applications/mampstack-7.4.7-0/apache2/htdocs/mycoursework/resources/views/inc/footer.blade.php ENDPATH**/ ?>