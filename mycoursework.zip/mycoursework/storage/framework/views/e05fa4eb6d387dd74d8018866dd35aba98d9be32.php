<?php $__env->startSection('title'); ?>Ваші записи<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="h_m">Ваші записи</h1>
    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $el): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="alert_messages">
            <h3><?php echo e($el->message); ?></h3>
            <p><?php echo e($el->email); ?></p>
            <p><small><?php echo e($el->created_at); ?></small></p>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/mampstack-7.4.7-0/apache2/htdocs/mycoursework/resources/views/messages.blade.php ENDPATH**/ ?>