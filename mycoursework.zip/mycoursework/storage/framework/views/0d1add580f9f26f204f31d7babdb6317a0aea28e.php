<?php $__env->startSection('title'); ?>Про нас<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="block1">
        <div class="but1">HEALTHY TEETH - сучасна стоматологія</div>
        <img class="back1" src="<?php echo e(asset('img/back1.png')); ?>">
    </div>
    <div class="block2">
        <h1 class="h_l">Cучасна діагностична клініка</h1>
        <div class="content1">
            <div class="content1_l">
                <img class="micro" src="<?php echo e(asset('img/microscope.jpg')); ?>">
            </div>
            <div class="content1_r">
                <div class="content1_r1">
                    Наша клініка пропонує різні види медичної допомоги з усім необхідним обладнанням. Діагностика, лікування та профілактика захворювань в усіх напрямках сучасної стоматології. Тут працюють тільки досвідчені і кваліфіковані лікарі різних спеціальностей. У нашій клініці кожен пацієнт отримає індивідуальний комплексний підхід і лікування.
                </div>
                <div class="content1_r2">
                    <div class="stamp_label">
                        <div class="stamp"><img class="stamp_pic" src="<?php echo e(asset('img/stamp.png')); ?>"></div>
                        <div class="stamp_text">Сучасне обладнання</div>
                    </div>
                    <div class="stamp_label">
                        <div class="stamp"><img class="stamp_pic" src="<?php echo e(asset('img/stamp.png')); ?>"></div>
                        <div class="stamp_text">Кваліфіковані лікарі</div>
                    </div>
                    <div class="stamp_label">
                        <div class="stamp"><img class="stamp_pic" src="<?php echo e(asset('img/stamp.png')); ?>"></div>
                        <div class="stamp_text">Доступні ціни</div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="block3">
        <h1 class="h_l">Чому саме ми?</h1>
        <div class=content2>
            <div class="mark">
                <div class="mark_p"><img src="<?php echo e(asset('img/mark1.png')); ?>"></div>
                <a class="mark_text">Кожен пацієнт - улюблений</a>
            </div>

            <div class="mark">
                <div class="mark_p"><img src="<?php echo e(asset('img/mark2.png')); ?>"></div>
                <a class="mark_text">Наша гарантія - це наші спеціалісти</a>
            </div>

            <div class="mark">
                <div class="mark_p"><img src="<?php echo e(asset('img/mark3.png')); ?>"></div>
                <a class="mark_text">Найкращі ціни в Києві</a>
            </div>

            <div class="mark">
                <div class="mark_p"><img src="<?php echo e(asset('img/mark4.png')); ?>"></div>
                <a class="mark_text">Ніякого болю</a>
            </div>

            <div class="mark">
                <div class="mark_p"><img src="<?php echo e(asset('img/mark5.png')); ?>"></div>
                <a class="mark_text">Молодість - великий плюс</a>
            </div>

            <div class="mark">
                <div class="mark_p"><img src="<?php echo e(asset('img/mark6.png')); ?>"></div>
                <a class="mark_text">Максимально комфортні умови</a>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/mampstack-7.4.7-0/apache2/htdocs/mycoursework/resources/views/landing.blade.php ENDPATH**/ ?>