<header>
    <div class="container">
        <a href="<?php echo e(route('landing')); ?>"><img class="logo_pic" src="<?php echo e(asset('img/logo.png')); ?>"></a>
        <label for="toggle-1" class="toggle-menu"><ul><li></li> <li></li> <li></li></ul></label>
        <input type="checkbox" id="toggle-1">
        <nav>
            <ul>
                <li><a href="<?php echo e(route('landing')); ?>">Про нас</a></li>
                <li><a href="<?php echo e(route('orthodontics')); ?>">Ортодонтія</a></li>
                <li><a href="<?php echo e(route('therapy')); ?>">Терапевтія</a></li>
                <li><a href="<?php echo e(route('surgery')); ?>">Хірургія</a></li>
                <li><a href="<?php echo e(route('contact')); ?>">Заявка</a></li>
                <li><a href="<?php echo e(route('contact-data')); ?>">Ваші записи</a></li>
            </ul>
        </nav>
    </div>
</header>
<?php /**PATH /Applications/mampstack-7.4.7-0/apache2/htdocs/mycoursework/resources/views/inc/header.blade.php ENDPATH**/ ?>