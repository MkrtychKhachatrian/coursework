<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('landing');
})->name('landing');

Route::get('/orthodontics', function () {
    return view('orthodontics');
})->name('orthodontics');

Route::get('/therapy', function () {
    return view('therapy');
})->name('therapy');

Route::get('/surgery', function () {
    return view('surgery');
})->name('surgery');

Route::get('/contact', function () {
    return view('contact');
})->name('contact');

Route::get('/contact/all', 'ContactController@allData')->name('contact-data');
Route::post('/contact/submit', 'ContactController@submit')->name('contact-form');







